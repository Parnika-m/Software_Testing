const folderId = "1YHDfQNxN9tatehJWb0epepSoS3gYuhhn";

module.exports = folderId;