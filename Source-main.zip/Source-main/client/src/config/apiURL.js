
const apiURL = process.env.REACT_APP_apiURL

export default apiURL;